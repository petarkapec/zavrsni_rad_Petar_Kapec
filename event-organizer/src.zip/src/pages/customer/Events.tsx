"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Link } from "react-router-dom"
import api from "../../services/api"
import { Calendar, Search, Filter, MapPin, Users } from "lucide-react"

type Event = {
  dogadjajId: number
  naziv: string
  opis: string
  ukCijenaPoOsobi: number
  ukCijenaFiksna: number
  prostorNaziv: string
  prostorAdresa: string
  prostorKapacitet: number
  organizatorIme: string
  organizatorPrezime: string
}

type FilterOptions = {
  minPrice: number
  maxPrice: number
  minCapacity: number
  maxCapacity: number
}

const CustomerEvents = () => {
  const [events, setEvents] = useState<Event[]>([])
  const [filteredEvents, setFilteredEvents] = useState<Event[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [showFilters, setShowFilters] = useState(false)
  const [filterOptions, setFilterOptions] = useState<FilterOptions>({
    minPrice: 0,
    maxPrice: 1000,
    minCapacity: 0,
    maxCapacity: 1000,
  })

  useEffect(() => {
    // Provjerite funkciju fetchEvents i dodajte console.log za debugging
    const fetchEvents = async () => {
      try {
        const response = await api.get("/dogadjaji")
        console.log("Dohvaćeni događaji:", response.data)

        // Dodajte dodatne informacije o prostoru za svaki događaj
        const eventsWithSpaceDetails = await Promise.all(
          response.data.map(async (event) => {
            try {
              const spaceResponse = await api.get(`/prostori/${event.prostor}`)
              return {
                dogadjajId: event.dogadjajId,
                naziv: event.naziv,
                opis: event.opis,
                ukCijenaPoOsobi: Number.parseFloat(event.ukCijenaPoOsobi || "0"),
                ukCijenaFiksna: Number.parseFloat(event.ukCijenaFiksna || "0"),
                prostorNaziv: spaceResponse.data.naziv,
                prostorAdresa: spaceResponse.data.adresa,
                prostorKapacitet: spaceResponse.data.kapacitet,
                organizatorIme: "Organizator", // Default vrijednost
                organizatorPrezime: "",
              }
            } catch (error) {
              console.error(`Greška pri dohvaćanju prostora za događaj ${event.dogadjajId}:`, error)
              return {
                dogadjajId: event.dogadjajId,
                naziv: event.naziv,
                opis: event.opis,
                ukCijenaPoOsobi: Number.parseFloat(event.ukCijenaPoOsobi || "0"),
                ukCijenaFiksna: Number.parseFloat(event.ukCijenaFiksna || "0"),
                prostorNaziv: "Nepoznato mjesto",
                prostorAdresa: "",
                prostorKapacitet: 0,
                organizatorIme: "Organizator",
                organizatorPrezime: "",
              }
            }
          }),
        )

        console.log("Događaji s detaljima prostora:", eventsWithSpaceDetails)
        setEvents(eventsWithSpaceDetails)
        setFilteredEvents(eventsWithSpaceDetails)
      } catch (error) {
        console.error("Greška pri dohvaćanju događaja:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchEvents()
  }, [])

  useEffect(() => {
    // Apply filters and search
    let result = events

    // Apply search term
    if (searchTerm) {
      result = result.filter(
        (event) =>
          (event.naziv && event.naziv.toLowerCase().includes(searchTerm.toLowerCase())) ||
          (event.opis && event.opis.toLowerCase().includes(searchTerm.toLowerCase())) ||
          (event.prostorNaziv && event.prostorNaziv.toLowerCase().includes(searchTerm.toLowerCase())) ||
          (event.prostorAdresa && event.prostorAdresa.toLowerCase().includes(searchTerm.toLowerCase())),
      )
    }

    // Apply filters
    result = result.filter((event) => {
      const totalMinPrice = (event.ukCijenaFiksna || 0) + (event.ukCijenaPoOsobi || 0)
      return (
        totalMinPrice >= filterOptions.minPrice &&
        totalMinPrice <= filterOptions.maxPrice &&
        (event.prostorKapacitet || 0) >= filterOptions.minCapacity &&
        (event.prostorKapacitet || 0) <= filterOptions.maxCapacity
      )
    })

    setFilteredEvents(result)
  }, [searchTerm, filterOptions, events])

  const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFilterOptions((prev) => ({
      ...prev,
      [name]: Number.parseFloat(value),
    }))
  }

  if (loading) {
    return <div className="flex justify-center items-center h-64">Loading...</div>
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-gray-900">Browse Events</h1>
        <p className="mt-1 text-sm text-gray-500">Find and book your perfect event.</p>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-grow">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="text"
            placeholder="Search events, locations..."
            className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <button
          onClick={() => setShowFilters(!showFilters)}
          className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
        >
          <Filter className="h-4 w-4 mr-2" />
          Filters
        </button>
      </div>

      {showFilters && (
        <div className="bg-white p-4 rounded-md shadow">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Filter Options</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="minPrice" className="block text-sm font-medium text-gray-700">
                Min Price (€)
              </label>
              <input
                type="range"
                id="minPrice"
                name="minPrice"
                min="0"
                max="1000"
                step="10"
                value={filterOptions.minPrice}
                onChange={handleFilterChange}
                className="mt-1 block w-full"
              />
              <div className="text-sm text-gray-500 mt-1">{filterOptions.minPrice} €</div>
            </div>
            <div>
              <label htmlFor="maxPrice" className="block text-sm font-medium text-gray-700">
                Max Price (€)
              </label>
              <input
                type="range"
                id="maxPrice"
                name="maxPrice"
                min="0"
                max="1000"
                step="10"
                value={filterOptions.maxPrice}
                onChange={handleFilterChange}
                className="mt-1 block w-full"
              />
              <div className="text-sm text-gray-500 mt-1">{filterOptions.maxPrice} €</div>
            </div>
            <div>
              <label htmlFor="minCapacity" className="block text-sm font-medium text-gray-700">
                Min Capacity
              </label>
              <input
                type="range"
                id="minCapacity"
                name="minCapacity"
                min="0"
                max="1000"
                step="10"
                value={filterOptions.minCapacity}
                onChange={handleFilterChange}
                className="mt-1 block w-full"
              />
              <div className="text-sm text-gray-500 mt-1">{filterOptions.minCapacity} people</div>
            </div>
            <div>
              <label htmlFor="maxCapacity" className="block text-sm font-medium text-gray-700">
                Max Capacity
              </label>
              <input
                type="range"
                id="maxCapacity"
                name="maxCapacity"
                min="0"
                max="1000"
                step="10"
                value={filterOptions.maxCapacity}
                onChange={handleFilterChange}
                className="mt-1 block w-full"
              />
              <div className="text-sm text-gray-500 mt-1">{filterOptions.maxCapacity} people</div>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {filteredEvents.length > 0 ? (
          filteredEvents.map((event) => (
            <Link
              key={event.dogadjajId}
              to={`/customer/events/${event.dogadjajId}`}
              className="bg-white overflow-hidden shadow rounded-lg hover:shadow-md transition-shadow duration-300"
            >
              <div className="h-40 bg-gray-200 flex items-center justify-center">
                <Calendar className="h-12 w-12 text-gray-400" />
              </div>
              <div className="p-4">
                <h3 className="text-lg font-medium text-indigo-600 truncate">{event.naziv}</h3>
                <p className="mt-1 text-sm text-gray-500 line-clamp-2">{event.opis}</p>
                <div className="mt-4 flex items-center">
                  <MapPin className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                  <p className="text-sm text-gray-500 truncate">{event.prostorNaziv || "Nepoznato mjesto"}</p>
                </div>
                <div className="mt-2 flex items-center">
                  <Users className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                  <p className="text-sm text-gray-500">Up to {event.prostorKapacitet || 0} guests</p>
                </div>
                <div className="mt-4 flex justify-between items-center">
                  <div className="text-sm font-medium text-gray-900">
                    From {((event.ukCijenaFiksna || 0) + (event.ukCijenaPoOsobi || 0)).toFixed(2)} €
                  </div>
                  <div className="text-xs text-gray-500">
                    By {event.organizatorIme || "Organizator"} {event.organizatorPrezime || ""}
                  </div>
                </div>
              </div>
            </Link>
          ))
        ) : (
          <div className="col-span-full text-center py-12 text-gray-500">No events found matching your criteria.</div>
        )}
      </div>
    </div>
  )
}

export default CustomerEvents
