"use client"

import { useState, useEffect } from "react"
import { useParams, useNavigate } from "react-router-dom"
import api from "../../services/api"
import { Calendar, MapPin, Users, Clock, CreditCard, Plus, X } from "lucide-react"

type Event = {
  dogadjajId: number
  naziv: string
  opis: string
  ukCijenaPoOsobi: number | null
  ukCijenaFiksna: number | null
  otkazniRok: number
  prostorId: number
  prostorNaziv: string
  prostorAdresa: string
  prostorKapacitet: number
  organizatorIme: string
  organizatorPrezime: string
}

type Offer = {
  ponudaId: number
  naziv: string
  opis: string
  cijena: number
  tipCijene: "FIKSNO" | "PO_OSOBI"
  kategorija: string
}

type Termin = {
  terminId: number
  datumPocetka: string
  datumZavrsetka: string
  zauzeto: boolean
}

type Guest = {
  id: string
  ime: string
  prezime: string
  email: string
}

const EventDetails = () => {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const [event, setEvent] = useState<Event | null>(null)
  const [offers, setOffers] = useState<Offer[]>([])
  const [termini, setTermini] = useState<Termin[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedTermin, setSelectedTermin] = useState<number | null>(null)
  const [showReservationModal, setShowReservationModal] = useState(false)
  const [guests, setGuests] = useState<Guest[]>([{ id: "1", ime: "", prezime: "", email: "" }])
  const [specialRequests, setSpecialRequests] = useState("")
  const [totalPrice, setTotalPrice] = useState(0)
  const [savedGuestLists, setSavedGuestLists] = useState<{ id: number; name: string }[]>([])
  const [selectedGuestList, setSelectedGuestList] = useState<number | null>(null)
  const [reservationSuccess, setReservationSuccess] = useState(false)

  useEffect(() => {
    const fetchEventDetails = async () => {
      try {
        const eventResponse = await api.get(`/dogadjaji/${id}`)
        setEvent(eventResponse.data)

        const offersResponse = await api.get(`/dogadjaji/${id}/ponude`)
        setOffers(offersResponse.data)

        const terminiResponse = await api.get(`/dogadjaji/${id}/termini`)
        console.log("Fetched termini:", terminiResponse.data)
        setTermini(terminiResponse.data)

        try {
          const guestListsResponse = await api.get("/korisnici/me/gosti")
          setSavedGuestLists(guestListsResponse.data)
        } catch (error) {
          console.error("Failed to fetch guest lists", error)
        }
      } catch (error) {
        console.error("Failed to fetch event details", error)
      } finally {
        setLoading(false)
      }
    }

    fetchEventDetails()
  }, [id])

  useEffect(() => {
    if (event) {
      calculateTotalPrice()
    }
  }, [event, guests])

  const calculateTotalPrice = () => {
    if (!event) return

    // Handle null values by defaulting to 0
    const fixedPrice = Number(event.ukCijenaFiksna || 0)
    const perPersonPrice = Number(event.ukCijenaPoOsobi || 0) * guests.length

    // Ensure we're adding numbers, not concatenating strings
    setTotalPrice(fixedPrice + perPersonPrice)
  }

  const handleAddGuest = () => {
    setGuests([...guests, { id: Date.now().toString(), ime: "", prezime: "", email: "" }])
  }

  const handleRemoveGuest = (id: string) => {
    if (guests.length > 1) {
      setGuests(guests.filter((guest) => guest.id !== id))
    }
  }

  const handleGuestChange = (id: string, field: keyof Guest, value: string) => {
    setGuests(guests.map((guest) => (guest.id === id ? { ...guest, [field]: value } : guest)))
  }

  const handleGuestListSelect = async (listId: number) => {
    try {
      const response = await api.get(`/customer/guest-lists/${listId}`)
      setGuests(
        response.data.guests.map((g: any, index: number) => ({
          ...g,
          id: index.toString(),
        })),
      )
      setSelectedGuestList(listId)
    } catch (error) {
      console.error("Failed to load guest list", error)
    }
  }

  const handleReservationSubmit = async () => {
    if (!event || !selectedTermin) return

    try {
      await api.post("/customer/reservations", {
        dogadjajId: event.dogadjajId,
        terminId: selectedTermin,
        posebni_zahtjevi: specialRequests,
        ukupnaCijena: totalPrice,
        gosti: guests.map((g) => ({
          ime: g.ime,
          prezime: g.prezime,
          email: g.email,
        })),
      })

      setReservationSuccess(true)
    } catch (error) {
      console.error("Failed to create reservation", error)
    }
  }

  const handlePayment = async () => {
    // In a real app, this would integrate with a payment gateway
    // For now, we'll just simulate a successful payment
    setTimeout(() => {
      navigate("/customer/reservations")
    }, 1500)
  }

  if (loading) {
    return <div className="flex justify-center items-center h-64">Loading...</div>
  }

  if (!event) {
    return <div className="text-center py-12">Event not found.</div>
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleString()
  }

  // Safe price formatting function that handles null values
  const formatPrice = (price: number | null): string => {
    return `${Number(price || 0).toFixed(2)} €`
  }

  return (
    <div className="space-y-6">
      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <div className="px-4 py-5 sm:px-6 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{event.naziv}</h1>
            <p className="mt-1 max-w-2xl text-sm text-gray-500">
              Organized by {event.organizatorIme} {event.organizatorPrezime}
            </p>
          </div>
          <button
            onClick={() => setShowReservationModal(true)}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            Book Now
          </button>
        </div>
        <div className="border-t border-gray-200">
          <dl>
            <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
              <dt className="text-sm font-medium text-gray-500">Description</dt>
              <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">{event.opis}</dd>
            </div>
            <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
              <dt className="text-sm font-medium text-gray-500">Location</dt>
              <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                <div className="flex items-center">
                  <MapPin className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                  {event.prostorNaziv}, {event.prostorAdresa}
                </div>
              </dd>
            </div>
            <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
              <dt className="text-sm font-medium text-gray-500">Capacity</dt>
              <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                <div className="flex items-center">
                  <Users className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                  Up to {event.prostorKapacitet} guests
                </div>
              </dd>
            </div>
            <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
              <dt className="text-sm font-medium text-gray-500">Pricing</dt>
              <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Fixed price:</span>
                    <span>{formatPrice(event.ukCijenaFiksna)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Price per person:</span>
                    <span>{formatPrice(event.ukCijenaPoOsobi)}</span>
                  </div>
                  <div className="pt-2 border-t border-gray-200 flex justify-between font-medium">
                    <span>Starting from:</span>
                    <span>{formatPrice(Number(event.ukCijenaFiksna || 0) + Number(event.ukCijenaPoOsobi || 0))}</span>
                  </div>
                </div>
              </dd>
            </div>
            <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
              <dt className="text-sm font-medium text-gray-500">Cancellation Policy</dt>
              <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                <div className="flex items-center">
                  <Clock className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                  {event.otkazniRok} days before the event
                </div>
              </dd>
            </div>
          </dl>
        </div>
      </div>

      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <div className="px-4 py-5 sm:px-6">
          <h2 className="text-lg font-medium text-gray-900">Included Offers</h2>
          <p className="mt-1 max-w-2xl text-sm text-gray-500">Services and items included in this event.</p>
        </div>
        <div className="border-t border-gray-200">
          <ul className="divide-y divide-gray-200">
            {offers.length > 0 ? (
              offers.map((offer) => (
                <li key={offer.ponudaId} className="px-4 py-4 sm:px-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-900">{offer.naziv}</p>
                      <p className="text-sm text-gray-500">{offer.opis}</p>
                    </div>
                    <div className="flex items-center">
                      <span className="px-2 py-1 text-xs font-medium rounded-full bg-gray-100 text-gray-800">
                        {offer.kategorija}
                      </span>
                      <span className="ml-2 px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800">
                        {offer.cijena} € ({offer.tipCijene})
                      </span>
                    </div>
                  </div>
                </li>
              ))
            ) : (
              <li className="px-4 py-5 text-center text-gray-500">No offers available for this event.</li>
            )}
          </ul>
        </div>
      </div>

      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <div className="px-4 py-5 sm:px-6">
          <h2 className="text-lg font-medium text-gray-900">Available Dates</h2>
          <p className="mt-1 max-w-2xl text-sm text-gray-500">Select a date for your reservation.</p>
        </div>
        <div className="border-t border-gray-200">
          <ul className="divide-y divide-gray-200">
            {termini.length > 0 ? (
              termini
                .filter((t) => !t.zauzeto)
                .map((termin) => (
                  <li key={termin.terminId} className="px-4 py-4 sm:px-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <Calendar className="flex-shrink-0 mr-3 h-5 w-5 text-gray-400" />
                        <div>
                          <p className="text-sm font-medium text-gray-900">
                            {formatDate(termin.datumPocetka)} - {formatDate(termin.datumZavrsetka)}
                          </p>
                        </div>
                      </div>
                      <button
                        onClick={() => {
                          setSelectedTermin(termin.terminId)
                          setShowReservationModal(true)
                        }}
                        className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-indigo-700 bg-indigo-100 hover:bg-indigo-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                      >
                        Select
                      </button>
                    </div>
                  </li>
                ))
            ) : (
              <li className="px-4 py-5 text-center text-gray-500">No available dates for this event.</li>
            )}
            {termini.length > 0 && termini.filter((t) => !t.zauzeto).length === 0 && (
              <li className="px-4 py-5 text-center text-gray-500">All dates are currently booked.</li>
            )}
          </ul>
        </div>
      </div>

      {/* Reservation Modal */}
      {showReservationModal && (
        <div className="fixed z-10 inset-0 overflow-y-auto">
          <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 transition-opacity" aria-hidden="true">
              <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
            </div>

            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">
              &#8203;
            </span>

            <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
              {!reservationSuccess ? (
                <>
                  <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                    <div className="sm:flex sm:items-start">
                      <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left w-full">
                        <h3 className="text-lg leading-6 font-medium text-gray-900">Make a Reservation</h3>
                        <div className="mt-4 space-y-4">
                          {!selectedTermin && (
                            <div>
                              <label className="block text-sm font-medium text-gray-700">Select a Date</label>
                              <select
                                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                                value={selectedTermin || ""}
                                onChange={(e) => setSelectedTermin(Number.parseInt(e.target.value))}
                              >
                                <option value="">Select a date</option>
                                {termini
                                  .filter((t) => !t.zauzeto)
                                  .map((termin) => (
                                    <option key={termin.terminId} value={termin.terminId}>
                                      {formatDate(termin.datumPocetka)} - {formatDate(termin.datumZavrsetka)}
                                    </option>
                                  ))}
                              </select>
                            </div>
                          )}

                          <div>
                            <div className="flex justify-between items-center">
                              <label className="block text-sm font-medium text-gray-700">Guest List</label>
                              <span className="text-xs text-gray-500">
                                {guests.length} {guests.length === 1 ? "guest" : "guests"}
                              </span>
                              {savedGuestLists.length > 0 && (
                                <div className="relative">
                                  <select
                                    className="block w-full pl-3 pr-10 py-1 text-xs border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 rounded-md"
                                    value={selectedGuestList || ""}
                                    onChange={(e) => handleGuestListSelect(Number.parseInt(e.target.value))}
                                  >
                                    <option value="">Load saved list</option>
                                    {savedGuestLists.map((list) => (
                                      <option key={list.id} value={list.id}>
                                        {list.name}
                                      </option>
                                    ))}
                                  </select>
                                </div>
                              )}
                            </div>
                            <div className="mt-2 space-y-3 max-h-60 overflow-y-auto">
                              {guests.map((guest, index) => (
                                <div key={guest.id} className="border border-gray-200 rounded-md p-3">
                                  <div className="flex justify-between items-center mb-2">
                                    <span className="text-sm font-medium">Guest {index + 1}</span>
                                    <button
                                      type="button"
                                      onClick={() => handleRemoveGuest(guest.id)}
                                      className="text-gray-400 hover:text-gray-500"
                                    >
                                      <X className="h-4 w-4" />
                                    </button>
                                  </div>
                                  <div className="grid grid-cols-2 gap-2">
                                    <div>
                                      <input
                                        type="text"
                                        placeholder="First Name"
                                        value={guest.ime}
                                        onChange={(e) => handleGuestChange(guest.id, "ime", e.target.value)}
                                        className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                                      />
                                    </div>
                                    <div>
                                      <input
                                        type="text"
                                        placeholder="Last Name"
                                        value={guest.prezime}
                                        onChange={(e) => handleGuestChange(guest.id, "prezime", e.target.value)}
                                        className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                                      />
                                    </div>
                                    <div className="col-span-2">
                                      <input
                                        type="email"
                                        placeholder="Email"
                                        value={guest.email}
                                        onChange={(e) => handleGuestChange(guest.id, "email", e.target.value)}
                                        className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                                      />
                                    </div>
                                  </div>
                                </div>
                              ))}
                              <button
                                type="button"
                                onClick={handleAddGuest}
                                className="flex items-center justify-center w-full py-2 px-4 border border-dashed border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                              >
                                <Plus className="h-4 w-4 mr-2" />
                                Add Guest
                              </button>
                            </div>
                          </div>

                          <div>
                            <label htmlFor="special-requests" className="block text-sm font-medium text-gray-700">
                              Special Requests
                            </label>
                            <textarea
                              id="special-requests"
                              rows={3}
                              className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                              placeholder="Any special requests or requirements..."
                              value={specialRequests}
                              onChange={(e) => setSpecialRequests(e.target.value)}
                            />
                          </div>

                          <div className="border-t border-gray-200 pt-4">
                            <div className="flex justify-between text-sm">
                              <span>Fixed price:</span>
                              <span>{formatPrice(event.ukCijenaFiksna)}</span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span>Per person ({guests.length} guests):</span>
                              <span>{formatPrice((event.ukCijenaPoOsobi || 0) * guests.length)}</span>
                            </div>
                            <div className="flex justify-between font-medium text-lg mt-2 pt-2 border-t border-gray-200">
                              <span>Total:</span>
                              <span>{formatPrice(totalPrice)}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                    <button
                      type="button"
                      onClick={handleReservationSubmit}
                      disabled={!selectedTermin || guests.some((g) => !g.ime || !g.prezime || !g.email)}
                      className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-indigo-600 text-base font-medium text-white hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:ml-3 sm:w-auto sm:text-sm disabled:opacity-50"
                    >
                      Reserve
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowReservationModal(false)}
                      className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
                    >
                      Cancel
                    </button>
                  </div>
                </>
              ) : (
                <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                  <div className="sm:flex sm:items-start">
                    <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left w-full">
                      <h3 className="text-lg leading-6 font-medium text-gray-900">Reservation Successful!</h3>
                      <div className="mt-4 space-y-4">
                        <p className="text-sm text-gray-500">
                          Your reservation has been created successfully. Please proceed to payment to confirm your
                          booking.
                        </p>
                        <div className="border-t border-gray-200 pt-4">
                          <div className="flex justify-between font-medium text-lg">
                            <span>Total Amount:</span>
                            <span>{formatPrice(totalPrice)}</span>
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={handlePayment}
                          className="w-full inline-flex justify-center items-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-green-600 text-base font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                        >
                          <CreditCard className="h-5 w-5 mr-2" />
                          Proceed to Payment
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default EventDetails
