import App from "../App"

export default function Page() {
  return <App />
}
