"use client"

import { useState, useEffect } from "react"
import api from "../../services/api"
import { Calendar, Clock, AlertTriangle, Check, X } from "lucide-react"

type Reservation = {
  rezervacija_id: number
  dogadjaj_naziv: string
  prostor_naziv: string
  datum_pocetka: string
  datum_zavrsetka: string
  ukupna_cijena: number
  status: "CEKA_POTVRDU" | "PLACENO" | "OTKAZANO"
  broj_gostiju: number
  posebni_zahtjevi?: string
}

const CustomerReservations = () => {
  const [reservations, setReservations] = useState<Reservation[]>([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState<"upcoming" | "past">("upcoming")

  useEffect(() => {
    fetchReservations()
  }, [])

  const fetchReservations = async () => {
    try {
      const response = await api.get("/rezervacije")
      setReservations(response.data)
    } catch (error) {
      console.error("Failed to fetch reservations", error)
    } finally {
      setLoading(false)
    }
  }

  const handleCancelReservation = async (id: number) => {
    if (window.confirm("Are you sure you want to cancel this reservation?")) {
      try {
        await api.put(`/customer/reservations/${id}/cancel`)
        fetchReservations()
      } catch (error) {
        console.error("Failed to cancel reservation", error)
      }
    }
  }

  const handlePayReservation = async (id: number) => {
    try {
      // In a real app, this would redirect to a payment gateway
      // For now, we'll just simulate a successful payment
      await api.put(`/customer/reservations/${id}/pay`)
      fetchReservations()
    } catch (error) {
      console.error("Failed to process payment", error)
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString() + " " + date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  const now = new Date()

  const upcomingReservations = reservations.filter((res) => new Date(res.datum_pocetka) > now)

  const pastReservations = reservations.filter((res) => new Date(res.datum_pocetka) <= now)

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "CEKA_POTVRDU":
        return (
          <span className="px-2 py-1 text-xs font-medium rounded-full bg-yellow-100 text-yellow-800 flex items-center">
            <Clock className="h-3 w-3 mr-1" />
            Awaiting Payment
          </span>
        )
      case "PLACENO":
        return (
          <span className="px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800 flex items-center">
            <Check className="h-3 w-3 mr-1" />
            Paid
          </span>
        )
      case "OTKAZANO":
        return (
          <span className="px-2 py-1 text-xs font-medium rounded-full bg-red-100 text-red-800 flex items-center">
            <X className="h-3 w-3 mr-1" />
            Cancelled
          </span>
        )
      default:
        return null
    }
  }

  if (loading) {
    return <div className="flex justify-center items-center h-64">Loading...</div>
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-gray-900">My Reservations</h1>
        <p className="mt-1 text-sm text-gray-500">Manage your upcoming and past reservations.</p>
      </div>

      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8" aria-label="Tabs">
          <button
            onClick={() => setActiveTab("upcoming")}
            className={`${
              activeTab === "upcoming"
                ? "border-indigo-500 text-indigo-600"
                : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
            } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
          >
            Upcoming ({upcomingReservations.length})
          </button>
          <button
            onClick={() => setActiveTab("past")}
            className={`${
              activeTab === "past"
                ? "border-indigo-500 text-indigo-600"
                : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
            } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
          >
            Past ({pastReservations.length})
          </button>
        </nav>
      </div>

      <div className="bg-white shadow overflow-hidden sm:rounded-md">
        <ul className="divide-y divide-gray-200">
          {(activeTab === "upcoming" ? upcomingReservations : pastReservations).length > 0 ? (
            (activeTab === "upcoming" ? upcomingReservations : pastReservations).map((reservation) => (
              <li key={reservation.rezervacija_id}>
                <div className="px-4 py-4 sm:px-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 bg-indigo-100 rounded-md p-2">
                        <Calendar className="h-6 w-6 text-indigo-600" />
                      </div>
                      <div className="ml-4">
                        <p className="text-sm font-medium text-indigo-600">{reservation.dogadjaj_naziv}</p>
                        <p className="text-sm text-gray-500">{reservation.prostor_naziv}</p>
                      </div>
                    </div>
                    <div className="flex items-center">{getStatusBadge(reservation.status)}</div>
                  </div>
                  <div className="mt-2 sm:flex sm:justify-between">
                    <div className="sm:flex">
                      <p className="flex items-center text-sm text-gray-500">
                        <Clock className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                        {formatDate(reservation.datum_pocetka)} - {formatDate(reservation.datum_zavrsetka)}
                      </p>
                    </div>
                    <div className="mt-2 flex items-center text-sm text-gray-500 sm:mt-0">
                      <div className="flex space-x-2">
                        <span className="px-2 py-1 text-xs font-medium bg-blue-100 text-blue-800 rounded-full">
                          {reservation.broj_gostiju} guests
                        </span>
                        <span className="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">
                          {reservation.ukupna_cijena} €
                        </span>
                      </div>
                    </div>
                  </div>
                  {reservation.posebni_zahtjevi && (
                    <div className="mt-2 flex items-center text-sm text-gray-500">
                      <AlertTriangle className="flex-shrink-0 mr-1.5 h-4 w-4 text-yellow-400" />
                      <p>Special requests: {reservation.posebni_zahtjevi}</p>
                    </div>
                  )}
                  {activeTab === "upcoming" && reservation.status !== "OTKAZANO" && (
                    <div className="mt-4 flex justify-end space-x-3">
                      {reservation.status === "CEKA_POTVRDU" && (
                        <button
                          onClick={() => handlePayReservation(reservation.rezervacija_id)}
                          className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                        >
                          Pay Now
                        </button>
                      )}
                      <button
                        onClick={() => handleCancelReservation(reservation.rezervacija_id)}
                        className="inline-flex items-center px-3 py-1 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                      >
                        Cancel
                      </button>
                    </div>
                  )}
                </div>
              </li>
            ))
          ) : (
            <li className="px-4 py-6 text-center text-gray-500">
              {activeTab === "upcoming"
                ? "You don't have any upcoming reservations."
                : "You don't have any past reservations."}
            </li>
          )}
        </ul>
      </div>
    </div>
  )
}

export default CustomerReservations
